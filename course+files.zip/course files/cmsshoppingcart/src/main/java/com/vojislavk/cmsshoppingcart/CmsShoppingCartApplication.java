package com.vojislavk.cmsshoppingcart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmsShoppingCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmsShoppingCartApplication.class, args);
	}

}
